/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paymentsystem;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author User
 */
public class PaymentSystem {
    public static Connection con;
    //public static String dbFile = "C://AccountsAndPaymentsSystem//PaymentSystem//src//paymentsystem//paymentdatabase//PaymentSystemDatabase.accdb";
    //public static String dbUrl = "jdbc:ucanaccess://"+dbFile.trim()+";memory=true";
   public static Connection getConnection(){
       String dbdir = "c:/db";
       File f = new File(dbdir);
       if(!f.exists())
           f.mkdir();
       String dbName = "PaymentSystemDatabase.accdb";
       String dbPatch = dbdir + "/" +dbName;
       File f2 = new File(dbPatch);
       if(!f2.exists()){  
       InputStream iStream = PaymentSystem.class.getResourceAsStream("paymentdatabase/"+dbName);
       try{
         Files.copy(iStream, f2.toPath(), StandardCopyOption.REPLACE_EXISTING);
       
       }catch(IOException e){
          e.printStackTrace();
       
       }}
       String dbUrl = "jdbc:ucanaccess://"+ dbPatch;
    try{
        con = DriverManager.getConnection(dbUrl,"","");
        
    }
    
    catch(Exception ex){
    System.out.println(""+ex);
    
    }
    return con;
    }
    
    public static void main(String[] args) {
         Openingform of = new Openingform();
        of.setVisible(true);
        try{
           
            for(int i = 0; i<=100;i++){
                 Thread.sleep(30);
                Openingform.jLabel2.setText(i+"%"+" Loading...");
     
               if(i==100){
               Openingform.jLabel2.setText("Completed");
               Login lf = new Login();
               lf.setVisible(true);  
               
               of.setVisible(false);    

               }
            
            
            }
        
        }catch(Exception Ex){
        }
    }
    
}
