/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paymentsystem;

import com.sun.glass.events.KeyEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author User
 */
public class Main extends javax.swing.JFrame {
     Connection con;
     ResultSet rs;
     PreparedStatement pst;
     Statement st;
    /**
     * Creates new form Main
     */
    public Main() {
        initComponents();
        showdate();
        showtime();
        section();
        strand();
        database();
        account();
        sectiondata();
        Stranddata();
        PriceItem();
    }
     public void account(){
     int c;
        try {
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("Select * from plogin");
            rs = pst.executeQuery();
            
            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();
            
            DefaultTableModel dft = (DefaultTableModel)jTable1.getModel();
            dft.setRowCount(0);
            
            while(rs.next())
            {
             Vector v2 = new Vector();
             for(int i=1; i<=c;i++)
             {
              
                v2.add(rs.getString("username"));
                v2.add(rs.getString("password"));
              
             
             }
             dft.addRow(v2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }}
     public void sectiondata(){
     int c;
        try {
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("Select * from Section");
            rs = pst.executeQuery();
            
            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();
            
            DefaultTableModel dft = (DefaultTableModel)jTable3.getModel();
            dft.setRowCount(0);
            
            while(rs.next())
            {
             Vector v2 = new Vector();
             for(int i=1; i<=c;i++)
             {
              
                v2.add(rs.getString("code"));
                v2.add(rs.getString("Sections"));
              
             
             }
             dft.addRow(v2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }}
     public void Stranddata(){
     int c;
        try {
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("Select * from Strand");
            rs = pst.executeQuery();
            
            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();
            
            DefaultTableModel dft = (DefaultTableModel)jTable4.getModel();
            dft.setRowCount(0);
            
            while(rs.next())
            {
             Vector v2 = new Vector();
             for(int i=1; i<=c;i++)
             {
              
                v2.add(rs.getString("Code"));
                v2.add(rs.getString("Strand"));
              
             
             }
             dft.addRow(v2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }}
     public void PriceItem(){
     int c;
        try {
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("Select * from Price");
            rs = pst.executeQuery();
            
            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();
            
            DefaultTableModel dft = (DefaultTableModel)jTable5.getModel();
            dft.setRowCount(0);
            
            while(rs.next())
            {
             Vector v2 = new Vector();
             for(int i=1; i<=c;i++)
             {
              
                v2.add(rs.getString("Price_Code"));
                v2.add(rs.getString("ID_Price"));
                v2.add(rs.getString("Uniform_Price"));
                v2.add(rs.getString("Class_Picture_Price"));
                v2.add(rs.getString("Graduation_Picture_Price"));    
             }
             dft.addRow(v2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }}
     public void database(){
     int c;
        try {
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("Select * from Student_Information");
            rs = pst.executeQuery();
            
            ResultSetMetaData rsd = rs.getMetaData();
            c = rsd.getColumnCount();
            
            DefaultTableModel dft = (DefaultTableModel)jTable2.getModel();
            dft.setRowCount(0);
            
            while(rs.next())
            {
             Vector v2 = new Vector();
             for(int i=1; i<=c;i++)
             { 
             
                v2.add(rs.getString("Name"));
                v2.add(rs.getString("Section"));
                v2.add(rs.getString("Strand"));
                v2.add(rs.getString("Status"));
                v2.add(rs.getString("MOA"));
                v2.add(rs.getString("Good_Moral"));
                v2.add(rs.getString("Form_138")); 
             }
             dft.addRow(v2);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(null, ex);
        }}
     void showdate() {
        Date d = new Date();
        SimpleDateFormat s = new SimpleDateFormat("MMMM dd, yyyy");
        lbldate.setText(s.format(d));
        
    }
    void showtime() {
        new Timer(0, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Date d = new Date();
                SimpleDateFormat s = new SimpleDateFormat("hh:mm:ss a");
                lbltime.setText(s.format(d));
                
            }
        }).start();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel32 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        lbltime = new javax.swing.JLabel();
        lbldate = new javax.swing.JLabel();
        btnminimize = new javax.swing.JButton();
        btnexit = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jButton3 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel32 = new javax.swing.JLabel();
        tab = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        rSButtonMetro2 = new rsbuttom.RSButtonMetro();
        rSButtonMetro3 = new rsbuttom.RSButtonMetro();
        jLabel1 = new javax.swing.JLabel();
        txtuser = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtpass = new javax.swing.JTextField();
        rSButtonMetro4 = new rsbuttom.RSButtonMetro();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel8 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtuserc = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtpassc = new javax.swing.JPasswordField();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel9 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txtusercp = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtpasscp = new javax.swing.JPasswordField();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        rSButtonMetro7 = new rsbuttom.RSButtonMetro();
        jPanel18 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txtsearch = new javax.swing.JTextField();
        jPanel20 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        txtname = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtsec = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtstrand = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtstatus = new javax.swing.JTextField();
        jPanel21 = new javax.swing.JPanel();
        cmoa = new javax.swing.JCheckBox();
        cgm = new javax.swing.JCheckBox();
        cf138 = new javax.swing.JCheckBox();
        cid = new javax.swing.JCheckBox();
        txtid = new javax.swing.JTextField();
        txtuniform = new javax.swing.JTextField();
        txtgp = new javax.swing.JTextField();
        cuniform = new javax.swing.JCheckBox();
        cgp = new javax.swing.JCheckBox();
        txtcp = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        ccp = new javax.swing.JCheckBox();
        jLabel17 = new javax.swing.JLabel();
        txtcode = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txtname1 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        cmoa1 = new javax.swing.JCheckBox();
        cgm1 = new javax.swing.JCheckBox();
        cf139 = new javax.swing.JCheckBox();
        cid1 = new javax.swing.JCheckBox();
        txtid1 = new javax.swing.JTextField();
        txtuniform1 = new javax.swing.JTextField();
        txtgp1 = new javax.swing.JTextField();
        cuniform1 = new javax.swing.JCheckBox();
        cgp1 = new javax.swing.JCheckBox();
        ccp1 = new javax.swing.JCheckBox();
        txtcp1 = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        ubtncancel = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        txtcode1 = new javax.swing.JTextField();
        ustatus = new javax.swing.JComboBox<>();
        ustrand = new javax.swing.JComboBox<>();
        usection = new javax.swing.JComboBox<>();
        jPanel12 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        txtname2 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        cmoa2 = new javax.swing.JCheckBox();
        cgm2 = new javax.swing.JCheckBox();
        cf140 = new javax.swing.JCheckBox();
        cid2 = new javax.swing.JCheckBox();
        txtid2 = new javax.swing.JTextField();
        txtuniform2 = new javax.swing.JTextField();
        txtgp2 = new javax.swing.JTextField();
        cuniform2 = new javax.swing.JCheckBox();
        cgp2 = new javax.swing.JCheckBox();
        ccp2 = new javax.swing.JCheckBox();
        txtcp2 = new javax.swing.JTextField();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        nstatus = new javax.swing.JComboBox<>();
        nsection = new javax.swing.JComboBox<>();
        jLabel21 = new javax.swing.JLabel();
        nstrand = new javax.swing.JComboBox<>();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jPanel26 = new javax.swing.JPanel();
        txtdcp = new javax.swing.JTextField();
        dccp = new javax.swing.JCheckBox();
        txtdid = new javax.swing.JTextField();
        txtduniform = new javax.swing.JTextField();
        did = new javax.swing.JCheckBox();
        txtdgp = new javax.swing.JTextField();
        duniform = new javax.swing.JCheckBox();
        dgp = new javax.swing.JCheckBox();
        jPanel27 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        jPanel28 = new javax.swing.JPanel();
        rSButtonMetro5 = new rsbuttom.RSButtonMetro();
        rSButtonMetro8 = new rsbuttom.RSButtonMetro();
        jLabel23 = new javax.swing.JLabel();
        txtcodes = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtsections = new javax.swing.JTextField();
        rSButtonMetro9 = new rsbuttom.RSButtonMetro();
        jPanel14 = new javax.swing.JPanel();
        jPanel29 = new javax.swing.JPanel();
        rSButtonMetro10 = new rsbuttom.RSButtonMetro();
        rSButtonMetro11 = new rsbuttom.RSButtonMetro();
        jLabel25 = new javax.swing.JLabel();
        txtcodestrand = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        txtstrandd = new javax.swing.JTextField();
        rSButtonMetro12 = new rsbuttom.RSButtonMetro();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jPanel30 = new javax.swing.JPanel();
        jPanel31 = new javax.swing.JPanel();
        rSButtonMetro14 = new rsbuttom.RSButtonMetro();
        jLabel27 = new javax.swing.JLabel();
        txtcodeprice = new javax.swing.JTextField();
        jLabel28 = new javax.swing.JLabel();
        txtuprice = new javax.swing.JTextField();
        jLabel29 = new javax.swing.JLabel();
        txtidprice = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        txtclassprice = new javax.swing.JTextField();
        jLabel31 = new javax.swing.JLabel();
        txtgradprice = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable5 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel32.setBackground(new java.awt.Color(204, 204, 204));
        jPanel32.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 540, 790, 40));

        jPanel2.setBackground(new java.awt.Color(153, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jPanel3MouseDragged(evt);
            }
        });
        jPanel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jPanel3MousePressed(evt);
            }
        });

        lbltime.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbltime.setForeground(new java.awt.Color(255, 255, 255));
        lbltime.setText("Time");

        lbldate.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lbldate.setForeground(new java.awt.Color(255, 255, 255));
        lbldate.setText("Date");

        btnminimize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Minimize.png"))); // NOI18N
        btnminimize.setToolTipText("Minimize");
        btnminimize.setBorder(null);
        btnminimize.setBorderPainted(false);
        btnminimize.setContentAreaFilled(false);
        btnminimize.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnminimize.setFocusPainted(false);
        btnminimize.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnminimize.setRequestFocusEnabled(false);
        btnminimize.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/Minimize1.png"))); // NOI18N
        btnminimize.setVerifyInputWhenFocusTarget(false);
        btnminimize.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnminimizeActionPerformed(evt);
            }
        });

        btnexit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/cicle1.png"))); // NOI18N
        btnexit.setToolTipText("Exit");
        btnexit.setBorder(null);
        btnexit.setBorderPainted(false);
        btnexit.setContentAreaFilled(false);
        btnexit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btnexit.setFocusPainted(false);
        btnexit.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnexit.setRequestFocusEnabled(false);
        btnexit.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/cicle.png"))); // NOI18N
        btnexit.setVerifyInputWhenFocusTarget(false);
        btnexit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnexitActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lbldate, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(93, 93, 93)
                .addComponent(lbltime, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 100, Short.MAX_VALUE)
                .addComponent(btnminimize)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnexit, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(lbltime, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnexit, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnminimize, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbldate, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 24));

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 204, 204)));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn3.png"))); // NOI18N
        jButton3.setBorderPainted(false);
        jButton3.setContentAreaFilled(false);
        jButton3.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton3.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn4.png"))); // NOI18N
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 123, 40));

        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn17.png"))); // NOI18N
        jButton17.setBorderPainted(false);
        jButton17.setContentAreaFilled(false);
        jButton17.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton17.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton17.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn18.png"))); // NOI18N
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton17, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 0, 123, 40));

        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn19.png"))); // NOI18N
        jButton18.setBorderPainted(false);
        jButton18.setContentAreaFilled(false);
        jButton18.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton18.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton18.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn20.png"))); // NOI18N
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton18, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, 123, 40));

        jButton19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn21.png"))); // NOI18N
        jButton19.setBorderPainted(false);
        jButton19.setContentAreaFilled(false);
        jButton19.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton19.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton19.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn22.png"))); // NOI18N
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton19, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 0, 123, 40));

        jButton16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn23.png"))); // NOI18N
        jButton16.setBorderPainted(false);
        jButton16.setContentAreaFilled(false);
        jButton16.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton16.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton16.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn24.png"))); // NOI18N
        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton16, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 0, 123, 40));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn1.png"))); // NOI18N
        jButton2.setBorderPainted(false);
        jButton2.setContentAreaFilled(false);
        jButton2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton2.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn2.png"))); // NOI18N
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 140, 40));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 124, 790, 35));

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 60)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(204, 204, 204));
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("Payment System");
        jPanel2.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, 560, 70));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 160));

        tab.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);
        tab.setToolTipText("");

        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel7.setBackground(new java.awt.Color(204, 204, 204));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rSButtonMetro2.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro2.setText("Create Account");
        rSButtonMetro2.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro2.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro2.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro2.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro2ActionPerformed(evt);
            }
        });
        jPanel7.add(rSButtonMetro2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 170, 44));

        rSButtonMetro3.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro3.setText("Change Password");
        rSButtonMetro3.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro3.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro3.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro3.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro3ActionPerformed(evt);
            }
        });
        jPanel7.add(rSButtonMetro3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 170, 44));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 51, 51));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Username:");
        jPanel7.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 20));

        txtuser.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtuser.setForeground(new java.awt.Color(51, 51, 51));
        txtuser.setEnabled(false);
        jPanel7.add(txtuser, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 20, 150, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Password:");
        jPanel7.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 170, 20));

        txtpass.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtpass.setForeground(new java.awt.Color(51, 51, 51));
        txtpass.setEnabled(false);
        jPanel7.add(txtpass, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 70, 150, -1));

        rSButtonMetro4.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro4.setText("Delete Account");
        rSButtonMetro4.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro4.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro4.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro4.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro4ActionPerformed(evt);
            }
        });
        jPanel7.add(rSButtonMetro4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 170, 44));

        jPanel6.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 380));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Username", "Password"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setSelectionBackground(new java.awt.Color(153, 153, 153));
        jTable1.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable1.getTableHeader().setResizingAllowed(false);
        jTable1.getTableHeader().setReorderingAllowed(false);
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
        }

        jPanel6.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(188, 11, 579, 360));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 785, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, 785, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 382, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, 382, Short.MAX_VALUE))
        );

        tab.addTab("", jPanel5);

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel16.setBackground(new java.awt.Color(204, 204, 204));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 51, 51));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Password:");
        jPanel16.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 90, 40));

        txtuserc.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtuserc.setForeground(new java.awt.Color(51, 51, 51));
        jPanel16.add(txtuserc, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 220, 40));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Username:");
        jPanel16.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 90, 40));

        txtpassc.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtpassc.setForeground(new java.awt.Color(51, 51, 51));
        txtpassc.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpasscKeyTyped(evt);
            }
        });
        jPanel16.add(txtpassc, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 220, 40));

        jButton4.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jButton4.setText("Cancel");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 110, 40));

        jButton5.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jButton5.setText("Save");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, 110, 40));

        jPanel8.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(183, 37, 390, 310));

        tab.addTab("", jPanel8);

        jPanel17.setBackground(new java.awt.Color(204, 204, 204));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Password:");
        jPanel17.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 120, 90, 40));

        txtusercp.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtusercp.setForeground(new java.awt.Color(51, 51, 51));
        txtusercp.setEnabled(false);
        jPanel17.add(txtusercp, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 70, 220, 40));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Username:");
        jPanel17.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 70, 90, 40));

        txtpasscp.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtpasscp.setForeground(new java.awt.Color(51, 51, 51));
        txtpasscp.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtpasscpKeyTyped(evt);
            }
        });
        jPanel17.add(txtpasscp, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, 220, 40));

        jButton6.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jButton6.setText("Cancel");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 190, 110, 40));

        jButton7.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jButton7.setText("Update");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel17.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 190, 110, 40));

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 785, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel9Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 382, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel9Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        tab.addTab("", jPanel9);

        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel19.setBackground(new java.awt.Color(204, 204, 204));
        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rSButtonMetro7.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro7.setText("Database");
        rSButtonMetro7.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro7.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro7.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro7.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro7ActionPerformed(evt);
            }
        });
        jPanel19.add(rSButtonMetro7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 170, 44));

        jPanel10.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 380));

        jPanel18.setBackground(new java.awt.Color(204, 204, 204));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel7.setText("Search Name");
        jPanel18.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 14, -1, -1));

        txtsearch.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtsearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtsearchKeyPressed(evt);
            }
        });
        jPanel18.add(txtsearch, new org.netbeans.lib.awtextra.AbsoluteConstraints(132, 11, 319, -1));

        jPanel20.setBackground(new java.awt.Color(153, 153, 153));
        jPanel20.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Student Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 17))); // NOI18N
        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel8.setText("Student Name:");
        jPanel20.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 37, 117, -1));

        txtname.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtname.setEnabled(false);
        jPanel20.add(txtname, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 34, 216, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel9.setText("Section:");
        jPanel20.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 70, 117, -1));

        txtsec.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtsec.setEnabled(false);
        jPanel20.add(txtsec, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 67, 160, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel10.setText("Strand");
        jPanel20.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 103, 117, -1));

        txtstrand.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtstrand.setEnabled(false);
        jPanel20.add(txtstrand, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 100, 160, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel11.setText("Status");
        jPanel20.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, -1, -1));

        txtstatus.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtstatus.setEnabled(false);
        jPanel20.add(txtstatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(357, 67, 150, -1));

        jPanel21.setBackground(new java.awt.Color(204, 204, 204));
        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cmoa.setText("MOA");
        cmoa.setContentAreaFilled(false);
        cmoa.setEnabled(false);
        jPanel21.add(cmoa, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 16, 61, -1));

        cgm.setText("Good Moral");
        cgm.setContentAreaFilled(false);
        cgm.setEnabled(false);
        jPanel21.add(cgm, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 49, -1, -1));

        cf138.setText("Form 138");
        cf138.setContentAreaFilled(false);
        cf138.setEnabled(false);
        jPanel21.add(cf138, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 82, -1, -1));

        cid.setText("ID");
        cid.setContentAreaFilled(false);
        cid.setEnabled(false);
        jPanel21.add(cid, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 16, 50, -1));

        txtid.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtid.setText("0");
        txtid.setEnabled(false);
        jPanel21.add(txtid, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 124, -1));

        txtuniform.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtuniform.setText("0");
        txtuniform.setEnabled(false);
        jPanel21.add(txtuniform, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 44, 124, -1));

        txtgp.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtgp.setText("0");
        txtgp.setEnabled(false);
        jPanel21.add(txtgp, new org.netbeans.lib.awtextra.AbsoluteConstraints(193, 77, 100, -1));

        cuniform.setText("Uniform");
        cuniform.setContentAreaFilled(false);
        cuniform.setEnabled(false);
        jPanel21.add(cuniform, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 40, 70, 30));

        cgp.setText("Grad Picture");
        cgp.setContentAreaFilled(false);
        cgp.setEnabled(false);
        jPanel21.add(cgp, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 80, 110, -1));

        txtcp.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtcp.setText("0");
        txtcp.setEnabled(false);
        jPanel21.add(txtcp, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 10, 100, -1));

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn5.png"))); // NOI18N
        jButton1.setBorderPainted(false);
        jButton1.setContentAreaFilled(false);
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn6.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel21.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 40, 90, 40));

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn9.png"))); // NOI18N
        jButton9.setBorderPainted(false);
        jButton9.setContentAreaFilled(false);
        jButton9.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton9.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn10.png"))); // NOI18N
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel21.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 70, 100, 40));

        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn13.png"))); // NOI18N
        jButton11.setBorderPainted(false);
        jButton11.setContentAreaFilled(false);
        jButton11.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton11.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn14.png"))); // NOI18N
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel21.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 40, 100, 40));

        ccp.setText("Class Picture");
        ccp.setContentAreaFilled(false);
        ccp.setEnabled(false);
        ccp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ccpActionPerformed(evt);
            }
        });
        jPanel21.add(ccp, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 10, 120, 30));

        jPanel20.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 540, 130));

        jLabel17.setText("Code:");
        jPanel20.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 26, -1, -1));

        txtcode.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtcode.setEnabled(false);
        jPanel20.add(txtcode, new org.netbeans.lib.awtextra.AbsoluteConstraints(453, 23, 58, -1));

        jPanel18.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 560, 280));

        jLabel16.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel16.setText("Press Enter to Search");
        jPanel18.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 10, 130, 33));

        jPanel10.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 15, 580, 350));

        tab.addTab("", jPanel10);

        jPanel22.setBackground(new java.awt.Color(153, 153, 153));
        jPanel22.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "Update Student Details", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 17))); // NOI18N
        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel12.setText("Student Name:");
        jPanel22.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 37, 117, -1));

        txtname1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jPanel22.add(txtname1, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 34, 216, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel13.setText("Section:");
        jPanel22.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 70, 117, -1));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel14.setText("Strand");
        jPanel22.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 103, 117, -1));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel15.setText("Status");
        jPanel22.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, -1, -1));

        jPanel23.setBackground(new java.awt.Color(204, 204, 204));
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cmoa1.setText("MOA");
        cmoa1.setContentAreaFilled(false);
        jPanel23.add(cmoa1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 16, 61, -1));

        cgm1.setText("Good Moral");
        cgm1.setContentAreaFilled(false);
        jPanel23.add(cgm1, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 49, -1, -1));

        cf139.setText("Form 138");
        cf139.setContentAreaFilled(false);
        jPanel23.add(cf139, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 82, -1, -1));

        cid1.setText("ID");
        cid1.setContentAreaFilled(false);
        cid1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cid1ActionPerformed(evt);
            }
        });
        jPanel23.add(cid1, new org.netbeans.lib.awtextra.AbsoluteConstraints(103, 16, -1, -1));

        txtid1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtid1.setText("0");
        txtid1.setEnabled(false);
        jPanel23.add(txtid1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 11, 124, -1));

        txtuniform1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtuniform1.setText("0");
        txtuniform1.setEnabled(false);
        jPanel23.add(txtuniform1, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 44, 124, -1));

        txtgp1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtgp1.setText("0");
        txtgp1.setEnabled(false);
        jPanel23.add(txtgp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(203, 77, 90, -1));

        cuniform1.setText("Uniform");
        cuniform1.setContentAreaFilled(false);
        cuniform1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cuniform1ActionPerformed(evt);
            }
        });
        jPanel23.add(cuniform1, new org.netbeans.lib.awtextra.AbsoluteConstraints(103, 43, 70, 30));

        cgp1.setText("Grad Picture");
        cgp1.setContentAreaFilled(false);
        cgp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cgp1ActionPerformed(evt);
            }
        });
        jPanel23.add(cgp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(103, 80, 100, -1));

        ccp1.setText("Class Picture");
        ccp1.setContentAreaFilled(false);
        ccp1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ccp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ccp1ActionPerformed(evt);
            }
        });
        jPanel23.add(ccp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 11, 110, 30));

        txtcp1.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtcp1.setText("0");
        txtcp1.setEnabled(false);
        jPanel23.add(txtcp1, new org.netbeans.lib.awtextra.AbsoluteConstraints(394, 11, 90, -1));

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn7.png"))); // NOI18N
        jButton8.setBorderPainted(false);
        jButton8.setContentAreaFilled(false);
        jButton8.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton8.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn8.png"))); // NOI18N
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel23.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 50, 90, 30));

        ubtncancel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn11.png"))); // NOI18N
        ubtncancel.setBorderPainted(false);
        ubtncancel.setContentAreaFilled(false);
        ubtncancel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        ubtncancel.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn12.png"))); // NOI18N
        ubtncancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ubtncancelActionPerformed(evt);
            }
        });
        jPanel23.add(ubtncancel, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 80, 100, 36));

        jPanel22.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 138, 492, 130));

        jLabel18.setText("Code:");
        jPanel22.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(416, 26, -1, -1));

        txtcode1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtcode1.setEnabled(false);
        jPanel22.add(txtcode1, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 23, 58, -1));

        ustatus.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        ustatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Status", "Present", "Dismissed" }));
        jPanel22.add(ustatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 65, 140, -1));

        ustrand.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        ustrand.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Strand" }));
        jPanel22.add(ustrand, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 100, 160, 30));

        usection.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        usection.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Section" }));
        jPanel22.add(usection, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 66, 160, 30));

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(144, 144, 144)
                .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE)
                .addGap(121, 121, 121))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jPanel22, javax.swing.GroupLayout.DEFAULT_SIZE, 280, Short.MAX_VALUE)
                .addGap(48, 48, 48))
        );

        tab.addTab("", jPanel11);

        jPanel24.setBackground(new java.awt.Color(153, 153, 153));
        jPanel24.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)), "New Student", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 17))); // NOI18N
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel19.setText("Student Name:");
        jPanel24.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 37, 117, -1));

        txtname2.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jPanel24.add(txtname2, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 34, 216, -1));

        jLabel20.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel20.setText("Section:");
        jPanel24.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 100, 120, -1));

        jLabel22.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel22.setText("Status");
        jPanel24.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 70, -1, -1));

        jPanel25.setBackground(new java.awt.Color(204, 204, 204));
        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        cmoa2.setText("MOA");
        cmoa2.setContentAreaFilled(false);
        jPanel25.add(cmoa2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 16, 61, -1));

        cgm2.setText("Good Moral");
        cgm2.setContentAreaFilled(false);
        jPanel25.add(cgm2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 49, -1, -1));

        cf140.setText("Form 138");
        cf140.setContentAreaFilled(false);
        jPanel25.add(cf140, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 82, -1, -1));

        cid2.setText("ID");
        cid2.setContentAreaFilled(false);
        cid2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cid2ActionPerformed(evt);
            }
        });
        jPanel25.add(cid2, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 16, -1, -1));

        txtid2.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtid2.setText("0");
        txtid2.setEnabled(false);
        jPanel25.add(txtid2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 11, 124, -1));

        txtuniform2.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtuniform2.setText("0");
        txtuniform2.setEnabled(false);
        jPanel25.add(txtuniform2, new org.netbeans.lib.awtextra.AbsoluteConstraints(169, 44, 124, -1));

        txtgp2.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtgp2.setText("0");
        txtgp2.setEnabled(false);
        jPanel25.add(txtgp2, new org.netbeans.lib.awtextra.AbsoluteConstraints(203, 77, 90, -1));

        cuniform2.setText("Uniform");
        cuniform2.setContentAreaFilled(false);
        cuniform2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cuniform2ActionPerformed(evt);
            }
        });
        jPanel25.add(cuniform2, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 43, -1, 30));

        cgp2.setText("Grad Picture");
        cgp2.setContentAreaFilled(false);
        cgp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cgp2ActionPerformed(evt);
            }
        });
        jPanel25.add(cgp2, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 70, 100, 40));

        ccp2.setText("Class Picture");
        ccp2.setContentAreaFilled(false);
        ccp2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        ccp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ccp2ActionPerformed(evt);
            }
        });
        jPanel25.add(ccp2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 10, 110, 30));

        txtcp2.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtcp2.setText("0");
        txtcp2.setEnabled(false);
        jPanel25.add(txtcp2, new org.netbeans.lib.awtextra.AbsoluteConstraints(394, 10, 90, -1));

        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn15.png"))); // NOI18N
        jButton12.setBorderPainted(false);
        jButton12.setContentAreaFilled(false);
        jButton12.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton12.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn16.png"))); // NOI18N
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel25.add(jButton12, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 50, 100, 40));

        jButton13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn11.png"))); // NOI18N
        jButton13.setBorderPainted(false);
        jButton13.setContentAreaFilled(false);
        jButton13.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton13.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn12.png"))); // NOI18N
        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });
        jPanel25.add(jButton13, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 80, 100, 36));

        jPanel24.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(15, 138, 492, 130));

        nstatus.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        nstatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Status", "Present", "Dismissed" }));
        jPanel24.add(nstatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 65, 140, 30));

        nsection.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        nsection.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Section" }));
        jPanel24.add(nsection, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 100, 150, 30));

        jLabel21.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        jLabel21.setText("Strand");
        jPanel24.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 70, 120, -1));

        nstrand.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        nstrand.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Strand" }));
        nstrand.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nstrandActionPerformed(evt);
            }
        });
        jPanel24.add(nstrand, new org.netbeans.lib.awtextra.AbsoluteConstraints(136, 66, 150, 30));

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(143, 143, 143)
                .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, 520, Short.MAX_VALUE)
                .addGap(122, 122, 122))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(54, 54, 54))
        );

        tab.addTab("", jPanel12);

        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane2.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane2.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Name", "Section", "Strand", "Status", "MOA", "Good Moral", "Form 138"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable2.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jTable2.setSelectionBackground(new java.awt.Color(153, 153, 153));
        jTable2.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable2.getTableHeader().setResizingAllowed(false);
        jTable2.getTableHeader().setReorderingAllowed(false);
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);
        if (jTable2.getColumnModel().getColumnCount() > 0) {
            jTable2.getColumnModel().getColumn(0).setResizable(false);
            jTable2.getColumnModel().getColumn(1).setResizable(false);
            jTable2.getColumnModel().getColumn(2).setResizable(false);
            jTable2.getColumnModel().getColumn(3).setResizable(false);
            jTable2.getColumnModel().getColumn(4).setResizable(false);
            jTable2.getColumnModel().getColumn(5).setResizable(false);
            jTable2.getColumnModel().getColumn(6).setResizable(false);
        }

        jPanel13.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 750, 240));

        jPanel26.setBackground(new java.awt.Color(204, 204, 204));
        jPanel26.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtdcp.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtdcp.setText("0");
        txtdcp.setEnabled(false);
        jPanel26.add(txtdcp, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 10, 90, -1));

        dccp.setText("Class Picture");
        dccp.setContentAreaFilled(false);
        dccp.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        dccp.setEnabled(false);
        dccp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dccpActionPerformed(evt);
            }
        });
        jPanel26.add(dccp, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 10, 110, 30));

        txtdid.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtdid.setText("0");
        txtdid.setEnabled(false);
        jPanel26.add(txtdid, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 10, 124, -1));

        txtduniform.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtduniform.setText("0");
        txtduniform.setEnabled(false);
        jPanel26.add(txtduniform, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 124, -1));

        did.setText("ID");
        did.setContentAreaFilled(false);
        did.setEnabled(false);
        did.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                didActionPerformed(evt);
            }
        });
        jPanel26.add(did, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 70, 30));

        txtdgp.setFont(new java.awt.Font("Tahoma", 0, 17)); // NOI18N
        txtdgp.setText("0");
        txtdgp.setEnabled(false);
        jPanel26.add(txtdgp, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 50, 90, -1));

        duniform.setText("Uniform");
        duniform.setContentAreaFilled(false);
        duniform.setEnabled(false);
        duniform.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                duniformActionPerformed(evt);
            }
        });
        jPanel26.add(duniform, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 70, 30));

        dgp.setText("Grad Picture");
        dgp.setContentAreaFilled(false);
        dgp.setEnabled(false);
        dgp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dgpActionPerformed(evt);
            }
        });
        jPanel26.add(dgp, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 50, 110, 30));

        jPanel13.add(jPanel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 490, 100));

        jPanel27.setBackground(new java.awt.Color(204, 204, 204));
        jPanel27.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn5.png"))); // NOI18N
        jButton10.setBorderPainted(false);
        jButton10.setContentAreaFilled(false);
        jButton10.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton10.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn6.png"))); // NOI18N
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 100, 40));

        jButton14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn9.png"))); // NOI18N
        jButton14.setBorderPainted(false);
        jButton14.setContentAreaFilled(false);
        jButton14.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton14.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn10.png"))); // NOI18N
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton14, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 110, 40));

        jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn13.png"))); // NOI18N
        jButton15.setBorderPainted(false);
        jButton15.setContentAreaFilled(false);
        jButton15.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton15.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/Images/btn14.png"))); // NOI18N
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel27.add(jButton15, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 110, 40));

        jPanel13.add(jPanel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 260, 250, 100));

        tab.addTab("", jPanel13);

        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Code", "Section"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable3.setSelectionBackground(new java.awt.Color(153, 153, 153));
        jTable3.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable3.getTableHeader().setResizingAllowed(false);
        jTable3.getTableHeader().setReorderingAllowed(false);
        jTable3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable3MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(jTable3);
        if (jTable3.getColumnModel().getColumnCount() > 0) {
            jTable3.getColumnModel().getColumn(0).setResizable(false);
            jTable3.getColumnModel().getColumn(1).setResizable(false);
        }

        jPanel15.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 30, 480, 330));

        jPanel28.setBackground(new java.awt.Color(204, 204, 204));
        jPanel28.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rSButtonMetro5.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro5.setText("Add New Section");
        rSButtonMetro5.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro5.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro5.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro5.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro5ActionPerformed(evt);
            }
        });
        jPanel28.add(rSButtonMetro5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 170, 44));

        rSButtonMetro8.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro8.setText("Update Section");
        rSButtonMetro8.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro8.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro8.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro8.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro8ActionPerformed(evt);
            }
        });
        jPanel28.add(rSButtonMetro8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 170, 44));

        jLabel23.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(51, 51, 51));
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("Code");
        jPanel28.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 20));

        txtcodes.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtcodes.setForeground(new java.awt.Color(51, 51, 51));
        txtcodes.setEnabled(false);
        jPanel28.add(txtcodes, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 20, 150, -1));

        jLabel24.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(51, 51, 51));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("Section");
        jPanel28.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 170, 20));

        txtsections.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtsections.setForeground(new java.awt.Color(51, 51, 51));
        jPanel28.add(txtsections, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 70, 150, -1));

        rSButtonMetro9.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro9.setText("Delete Section");
        rSButtonMetro9.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro9.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro9.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro9.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro9ActionPerformed(evt);
            }
        });
        jPanel28.add(rSButtonMetro9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 170, 44));

        jPanel15.add(jPanel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 380));

        tab.addTab("", jPanel15);

        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel29.setBackground(new java.awt.Color(204, 204, 204));
        jPanel29.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rSButtonMetro10.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro10.setText("Add New Strand");
        rSButtonMetro10.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro10.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro10.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro10.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro10ActionPerformed(evt);
            }
        });
        jPanel29.add(rSButtonMetro10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 120, 170, 44));

        rSButtonMetro11.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro11.setText("Update Strand");
        rSButtonMetro11.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro11.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro11.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro11.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro11ActionPerformed(evt);
            }
        });
        jPanel29.add(rSButtonMetro11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 170, 44));

        jLabel25.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(51, 51, 51));
        jLabel25.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel25.setText("Code");
        jPanel29.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 20));

        txtcodestrand.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtcodestrand.setForeground(new java.awt.Color(51, 51, 51));
        txtcodestrand.setEnabled(false);
        jPanel29.add(txtcodestrand, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 20, 150, -1));

        jLabel26.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(51, 51, 51));
        jLabel26.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel26.setText("Strand");
        jPanel29.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 170, 20));

        txtstrandd.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtstrandd.setForeground(new java.awt.Color(51, 51, 51));
        jPanel29.add(txtstrandd, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 70, 150, -1));

        rSButtonMetro12.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro12.setText("Delete Strand");
        rSButtonMetro12.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro12.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro12.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro12.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro12ActionPerformed(evt);
            }
        });
        jPanel29.add(rSButtonMetro12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 170, 44));

        jPanel14.add(jPanel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 380));

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Code", "Strand"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable4.setSelectionBackground(new java.awt.Color(153, 153, 153));
        jTable4.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable4.getTableHeader().setResizingAllowed(false);
        jTable4.getTableHeader().setReorderingAllowed(false);
        jTable4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable4MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable4);
        if (jTable4.getColumnModel().getColumnCount() > 0) {
            jTable4.getColumnModel().getColumn(0).setResizable(false);
            jTable4.getColumnModel().getColumn(1).setResizable(false);
        }

        jPanel14.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 30, 480, 330));

        tab.addTab("", jPanel14);

        jPanel30.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel31.setBackground(new java.awt.Color(204, 204, 204));
        jPanel31.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        rSButtonMetro14.setBackground(new java.awt.Color(102, 102, 102));
        rSButtonMetro14.setText("Update Price");
        rSButtonMetro14.setColorHover(new java.awt.Color(153, 153, 153));
        rSButtonMetro14.setColorNormal(new java.awt.Color(102, 102, 102));
        rSButtonMetro14.setColorPressed(new java.awt.Color(153, 153, 153));
        rSButtonMetro14.setColorTextNormal(javax.swing.UIManager.getDefaults().getColor("CheckBox.shadow"));
        rSButtonMetro14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rSButtonMetro14ActionPerformed(evt);
            }
        });
        jPanel31.add(rSButtonMetro14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 170, 44));

        jLabel27.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(51, 51, 51));
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setText("Code");
        jPanel31.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 20));

        txtcodeprice.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtcodeprice.setForeground(new java.awt.Color(51, 51, 51));
        txtcodeprice.setEnabled(false);
        jPanel31.add(txtcodeprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(7, 20, 150, -1));

        jLabel28.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(51, 51, 51));
        jLabel28.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel28.setText("Uniform Price");
        jPanel31.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, 170, 20));

        txtuprice.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtuprice.setForeground(new java.awt.Color(51, 51, 51));
        jPanel31.add(txtuprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 150, -1));

        jLabel29.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(51, 51, 51));
        jLabel29.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel29.setText("ID Price");
        jPanel31.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 170, 20));

        txtidprice.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtidprice.setForeground(new java.awt.Color(51, 51, 51));
        jPanel31.add(txtidprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 150, -1));

        jLabel30.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(51, 51, 51));
        jLabel30.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel30.setText("Class Picture Price");
        jPanel31.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 170, 20));

        txtclassprice.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtclassprice.setForeground(new java.awt.Color(51, 51, 51));
        jPanel31.add(txtclassprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 150, -1));

        jLabel31.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(51, 51, 51));
        jLabel31.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel31.setText("Graduation Pic Price");
        jPanel31.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 170, 20));

        txtgradprice.setFont(new java.awt.Font("Tahoma", 0, 15)); // NOI18N
        txtgradprice.setForeground(new java.awt.Color(51, 51, 51));
        jPanel31.add(txtgradprice, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 150, -1));

        jPanel30.add(jPanel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 170, 380));

        jTable5.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Code", "ID Price", "Uniform Price", "Class Pic Price", "Graduation Pic Price"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable5.setSelectionBackground(new java.awt.Color(153, 153, 153));
        jTable5.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jTable5.getTableHeader().setResizingAllowed(false);
        jTable5.getTableHeader().setReorderingAllowed(false);
        jTable5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable5MouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(jTable5);
        if (jTable5.getColumnModel().getColumnCount() > 0) {
            jTable5.getColumnModel().getColumn(0).setResizable(false);
            jTable5.getColumnModel().getColumn(1).setResizable(false);
            jTable5.getColumnModel().getColumn(2).setResizable(false);
            jTable5.getColumnModel().getColumn(3).setResizable(false);
            jTable5.getColumnModel().getColumn(4).setResizable(false);
        }

        jPanel30.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 30, 580, 330));

        tab.addTab("", jPanel30);

        jPanel1.add(tab, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 790, 410));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 790, 580));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
     public void section(){
     try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Section";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){
    String section = rs.getString("Sections");
    nsection.addItem(section);  
    usection.addItem(section);  
    }
    }
    
    catch(Exception ex){
    System.out.println(""+ex);
    }
     
     }
     
     public void strand(){
     try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Strand";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){
    String strand = rs.getString("Strand");
    nstrand.addItem(strand);  
    ustrand.addItem(strand);
    }
    }
    
    catch(Exception ex){
    System.out.println(""+ex);
    }
     
     }
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        tab.setSelectedIndex(0);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        tab.setSelectedIndex(3);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
         DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
         int selectedIndex = jTable1.getSelectedRow();
         
         txtuser.setText(model.getValueAt(selectedIndex, 0).toString());
         txtpass.setText(model.getValueAt(selectedIndex, 1).toString());
         txtusercp.setText(model.getValueAt(selectedIndex, 0).toString());
         txtpasscp.setText(model.getValueAt(selectedIndex, 1).toString());
    }//GEN-LAST:event_jTable1MouseClicked

    private void rSButtonMetro2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro2ActionPerformed
        tab.setSelectedIndex(1);
    }//GEN-LAST:event_rSButtonMetro2ActionPerformed

    private void txtpasscKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpasscKeyTyped
        txtpassc.setEchoChar('•');
    }//GEN-LAST:event_txtpasscKeyTyped

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        tab.setSelectedIndex(0);
        txtuserc.setText("");
        txtpassc.setText("");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        String user=txtuserc.getText();
        String pass=txtpassc.getText();

        try{

            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("insert into plogin (username,password) values (?,?)");

            pst.setString(1,user);
            pst.setString(2,pass);
            
            if(txtuserc.getText().isEmpty()){
                JOptionPane.showMessageDialog(rootPane,"Enter your username", "System",JOptionPane.WARNING_MESSAGE);      
            }else if(txtpassc.getText().isEmpty()){
                JOptionPane.showMessageDialog(rootPane,"Enter your password", "System",JOptionPane.WARNING_MESSAGE);
            }else{
                  st = con.createStatement();
                  String user1= "Select * From plogin where username='"+user+"'";
                  rs = st.executeQuery(user1);
                  if(rs.next()){
                  JOptionPane.showMessageDialog(rootPane,"Username is already exist", "System",JOptionPane.WARNING_MESSAGE);
                  }else{
                  st = con.createStatement();
                  String pass1= "Select * From plogin where password='"+pass+"'";
                  rs = st.executeQuery(pass1);       
                  if(rs.next()){
                   JOptionPane.showMessageDialog(rootPane,"Password is already exist", "System",JOptionPane.WARNING_MESSAGE);
                  }else{
                  
                  
                  
                  
            
            int  ok = JOptionPane.showConfirmDialog(rootPane,"Confirm to store", "System",JOptionPane.YES_NO_OPTION);
            if(ok==0){
                JOptionPane.showMessageDialog(rootPane,"Account has been saved", "System",1);
                pst.executeUpdate();
                account();
                txtuserc.setText("");
                txtpassc.setText("");
                tab.setSelectedIndex(0);
            }}
                  }}
        }catch(SQLException ex){
            System.out.println(""+ex);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void txtpasscpKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtpasscpKeyTyped
       txtpassc.setEchoChar('•');
    }//GEN-LAST:event_txtpasscpKeyTyped

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        tab.setSelectedIndex(0);
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
         DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
         int selectedIndex = jTable1.getSelectedRow();        
         String user = String.valueOf(model.getValueAt(selectedIndex, 0).toString());
          
         String pass=txtpasscp.getText();
             
         try {            
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("update plogin set password=? where username=?");   
            pst.setString(1, pass);
            pst.setString(2, user);
            if(txtpasscp.getText().isEmpty()){
                JOptionPane.showMessageDialog(rootPane,"Enter your password", "System",JOptionPane.WARNING_MESSAGE);
            }else{
            st = con.createStatement();
                  String pass1= "Select * From plogin where password='"+pass+"'";
                  rs = st.executeQuery(pass1);       
                  if(rs.next()){
                   JOptionPane.showMessageDialog(rootPane,"Password is already exist", "System",JOptionPane.WARNING_MESSAGE);
                  }else{
             int  ok = JOptionPane.showConfirmDialog(rootPane,"Confirm to update", "System",JOptionPane.YES_NO_OPTION);
             if(ok==0){
                 
            JOptionPane.showMessageDialog(this, "Password has been changed");
           
            pst.executeUpdate();
            tab.setSelectedIndex(0);
            account();
             }}
            
            }
                            
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, ex);
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void rSButtonMetro3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro3ActionPerformed
        
         if(jTable1.getSelectedRow()== -1){
           JOptionPane.showMessageDialog(rootPane, "Select from the table", "System",
                        JOptionPane.OK_OPTION);
        }else{  
        tab.setSelectedIndex(2);}
    }//GEN-LAST:event_rSButtonMetro3ActionPerformed

    private void rSButtonMetro4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro4ActionPerformed
        DefaultTableModel model = (DefaultTableModel)jTable1.getModel();
        
        
        if(jTable1.getSelectedRow()== -1){
           JOptionPane.showMessageDialog(rootPane, "Select from the table", "System",
                        JOptionPane.OK_OPTION);
        }else{  
        int selectedIndex = jTable1.getSelectedRow();    
        String user = String.valueOf(model.getValueAt(selectedIndex, 0).toString());
       
        int dialogresult = JOptionPane.showConfirmDialog(null, "Do you want to delete this account?","System",JOptionPane.YES_NO_OPTION);
        if(dialogresult==JOptionPane.YES_OPTION){   
            try {
                con = PaymentSystem.getConnection();
                pst = con.prepareStatement("delete from plogin where Username=?" );
                pst.setString(1, user);
                pst.executeUpdate();
                account();
                JOptionPane.showMessageDialog(this, "Account Deleted");
            } catch (SQLException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);}
            }}
    }//GEN-LAST:event_rSButtonMetro4ActionPerformed

    private void rSButtonMetro7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro7ActionPerformed
        tab.setSelectedIndex(6);
    }//GEN-LAST:event_rSButtonMetro7ActionPerformed

    private void txtsearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtsearchKeyPressed
      if(evt.getKeyCode() == KeyEvent.VK_ENTER){
      String name = txtsearch.getText();
      try{
        con = PaymentSystem.getConnection() ;
        String sql ="select * from Student_Information where Name=?";
        pst = con.prepareStatement(sql);
        pst.setString(1, name);
        rs = pst.executeQuery();
        if(rs.next() == false){
          JOptionPane.showMessageDialog(this, "Student not found");
          txtname.setText("");
          txtsec.setText("");
          txtstrand.setText("");
          txtstatus.setText("");
          cmoa.setSelected(false);
          cgm.setSelected(false);
          cf138.setSelected(false);  
          txtid.setText("0");
          cid.setSelected(false);
          txtuniform.setText("0");
          cuniform.setSelected(false);
          txtgp.setText("0");
          cgp.setSelected(false);
          txtcp.setText("0");
          ccp.setSelected(false);
        }else{
             String code,name1,sec,strand,status,moa,gm,form138,id,pid,uniform,pu,gp,pgp,cp,pcp;
             code = rs.getString("Code");
             txtcode.setText(code);
             name1 = rs.getString("Name");
             sec = rs.getString("Section");
             strand = rs.getString("Strand");
             status = rs.getString("Status");
             moa = rs.getString("MOA");
             gm = rs.getString("Good_Moral");
             form138 = rs.getString("Form_138");
             id = rs.getString("ID");
             pid = rs.getString("ID_Price");
             uniform = rs.getString("Uniform");
             pu = rs.getString("Uniform_Price");
             gp = rs.getString("Grad_Picture");
             pgp = rs.getString("Grad_Picture_Price");
             cp = rs.getString("Class_Picture");
             pcp = rs.getString("Class_Picture_Price");
             txtname.setText(name1.trim());
             txtsec.setText(sec.trim());
             txtstrand.setText(strand.trim());
             txtstatus.setText(status.trim());
             if(moa.equals("Checked")){
             cmoa.setSelected(true);  
             }else{
             cmoa.setSelected(false);     
             }if(gm.equals("Checked")){
             cgm.setSelected(true);
             }else{
             cgm.setSelected(false);
             }if(form138.equals("Checked")){
             cf138.setSelected(true);
             }else{
             cf138.setSelected(false);
             }if(id.equals("Checked")){
             cid.setSelected(true);
             txtid.setText(pid);
             }else{
             cid.setSelected(false);
             txtid.setText(pid);
             }if(uniform.equals("Checked")){
             cuniform.setSelected(true);
             txtuniform.setText(pu);
             }else{
             cuniform.setSelected(false);
             txtuniform.setText(pu);
             }if(gp.equals("Checked")){
             cgp.setSelected(true);
             txtgp.setText(pgp);
             }else{
             cgp.setSelected(false);
             txtgp.setText(pgp);
             }if(cp.equals("Checked")){
             ccp.setSelected(true);
             txtcp.setText(pcp);
             }else{
             ccp.setSelected(false);
             txtcp.setText(pcp);
             }
             
        }
      
      }catch(Exception ex){
         JOptionPane.showMessageDialog(this, ex);
      }
      
      
      }
    }//GEN-LAST:event_txtsearchKeyPressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String name = txtname.getText();
        section();
        strand();
        if(txtname.getText().isEmpty() || txtsec.getText().isEmpty() || txtstrand.getText().isEmpty() || txtstatus.getText().isEmpty()){
          JOptionPane.showMessageDialog(this, "Student not found");
        }else{
        try{
        con = PaymentSystem.getConnection() ;
        String sql ="select * from Student_Information where Name =?";
        pst = con.prepareStatement(sql);
        pst.setString(1, name);
        rs = pst.executeQuery();
        if(rs.next() == false){
          JOptionPane.showMessageDialog(this, "Student not found");
        
        }else{
             String code,name1,sec,strand,status,moa,gm,form138,id,pid,uniform,pu,gp,pgp,cp,pcp;
             code = rs.getString("Code");
             txtcode1.setText(code);
             name1 = rs.getString("Name");
             sec = rs.getString("Section");
             strand = rs.getString("Strand");
             status = rs.getString("Status");
             moa = rs.getString("MOA");
             gm = rs.getString("Good_Moral");
             form138 = rs.getString("Form_138");
             id = rs.getString("ID");
             pid = rs.getString("ID_Price");
             uniform = rs.getString("Uniform");
             pu = rs.getString("Uniform_Price");
             gp = rs.getString("Grad_Picture");
             pgp = rs.getString("Grad_Picture_Price");
             cp = rs.getString("Class_Picture");
             pcp = rs.getString("Class_Picture_Price");
             txtname1.setText(name1.trim());
             usection.setSelectedItem(sec);
             ustrand.setSelectedItem(strand);
             ustatus.setSelectedItem(status.trim());
             if(moa.equals("Checked")){
             cmoa1.setSelected(true);  
             }else{
             cmoa1.setSelected(false);     
             }if(gm.equals("Checked")){
             cgm1.setSelected(true);
             }else{
             cgm1.setSelected(false);
             }if(form138.equals("Checked")){
             cf139.setSelected(true);
             }else{
             cf139.setSelected(false);
             }if(id.equals("Checked")){
             cid1.setSelected(true);
             txtid1.setText(pid);
             }else{
             cid1.setSelected(false);
             txtid1.setText(pid);
             }if(uniform.equals("Checked")){
             cuniform1.setSelected(true);
             txtuniform1.setText(pu);
             }else{
             cuniform1.setSelected(false);
             txtuniform1.setText(pu);
             }if(gp.equals("Checked")){
             cgp1.setSelected(true);
             txtgp1.setText(pgp);
             }else{
             cgp1.setSelected(false);
             txtgp1.setText(pgp);
             }if(cp.equals("Checked")){
             ccp1.setSelected(true);
             txtcp1.setText(pcp);
             }else{
             ccp1.setSelected(false);
             txtcp1.setText(pcp);
             }
             tab.setSelectedIndex(4);
             txtcode.setText("");
             txtname.setText("");
             txtsec.setText("");
             txtstrand.setText("");
             txtstatus.setText("");
             cmoa.setSelected(false);
             cgm.setSelected(false);
             cf138.setSelected(false);  
             txtid.setText("");
             cid.setSelected(false);
             txtuniform.setText("");
             cuniform.setSelected(false);
             txtgp.setText("");
             cgp.setSelected(false);
             txtcp.setText("");
             ccp.setSelected(false);
             txtsearch.setText("");
        }
      
      }catch(Exception ex){
         JOptionPane.showMessageDialog(this, ex);
      } 
        }
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        String code = txtcode.getText();
        
        
        if(txtname.getText().isEmpty() || txtsec.getText().isEmpty() || txtstrand.getText().isEmpty() || txtstatus.getText().isEmpty()
                || txtcode.getText().isEmpty()){
          JOptionPane.showMessageDialog(this, "Student not found");
        }else{
        int dialogresult = JOptionPane.showConfirmDialog(null, "Do you want to delete this record?","System",JOptionPane.YES_NO_OPTION);
        if(dialogresult==JOptionPane.YES_OPTION)
        {
       try {
           
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("delete from Student_Information where Code=?" );  
            pst.setString(1, code);
            pst.executeUpdate();
            database();
            txtcode.setText("");
            txtname.setText("");
            txtsec.setText("");
            txtstrand.setText("");
            txtstatus.setText("");
            cmoa.setSelected(false);
            cgm.setSelected(false);
            cf138.setSelected(false);  
            txtid.setText("");
            cid.setSelected(false);
            txtuniform.setText("");
            cuniform.setSelected(false);
            txtgp.setText("");
            cgp.setSelected(false);
            txtcp.setText("");
            ccp.setSelected(false);
            txtsearch.setText("");
            JOptionPane.showMessageDialog(this, "Record Deleted");
            }  catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex);
            }
            
        
        }}
    }//GEN-LAST:event_jButton9ActionPerformed

    private void ubtncancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ubtncancelActionPerformed
        tab.setSelectedIndex(3);
        txtcode1.setText("");
        txtname1.setText("");
        txtsec.setText("");
        txtstrand.setText("");
        txtstatus.setText("");
        cmoa1.setSelected(false);
        cgm1.setSelected(false);
        cf139.setSelected(false);  
        txtid1.setText("");
        cid1.setSelected(false);
        txtuniform1.setText("");
        cuniform1.setSelected(false);
        txtgp1.setText("");
        cgp1.setSelected(false);
        txtcp1.setText("");
        ccp1.setSelected(false);
    }//GEN-LAST:event_ubtncancelActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
         String code = txtcode1.getText();
         String name = txtname1.getText(); 
         String sec = usection.getSelectedItem().toString();
         String str = ustrand.getSelectedItem().toString();
         String sta = ustatus.getSelectedItem().toString();
         String moa,gm,f138,id,pid,u,pu,gp,pgp,cp,pcp; 
         
         
         pid = txtid1.getText();
         pu = txtuniform1.getText();
         pgp = txtgp1.getText();
         pcp = txtcp1.getText();
         if(cmoa1.isSelected()){
           moa = "Checked";
         }else{
           moa = "Unchecked";
         }
         if(cgm1.isSelected()){
          gm = "Checked";
         }else{
         gm = "Unchecked";
         }if(cf139.isSelected()){
          f138 = "Checked";
         }else{
         f138 = "Unchecked";
         }if(cid1.isSelected()){
          id = "Checked";
         }else{
          id = "Unchecked"; 
         }if(cuniform1.isSelected()){
          u = "Checked";
         }else{
          u = "Unchecked";
         }if(cgp1.isSelected()){
          gp = "Checked";
         }else{
          gp = "Unchecked";
         }if(ccp1.isSelected()){
          cp = "Checked";
         }else{
          cp = "Unchecked";
         }
         try {         
            con = PaymentSystem.getConnection();
            String sql = "update Student_Information set Name=?,Section=?,Strand=?,Status=?,MOA=?,Good_Moral=?,Form_138=?,ID=?,ID_Price=?,Uniform=?,Uniform_Price=?,Grad_Picture=?,Grad_Picture_Price=?,Class_Picture=?,Class_Picture_Price=? where Code=?";
            pst = con.prepareStatement(sql);  
            pst.setString(1, name);
            pst.setString(2, sec);
            pst.setString(3, str);
            pst.setString(4, sta);
            pst.setString(5, moa);
            pst.setString(6, gm);
            pst.setString(7, f138);
            pst.setString(8, id);
            pst.setString(9, pid);
            pst.setString(10, u);
            pst.setString(11, pu);
            pst.setString(12, gp);
            pst.setString(13, pgp);
            pst.setString(14, cp);
            pst.setString(15, pcp);
            pst.setString(16, code);
             if(txtname1.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Enter your name","System",JOptionPane.WARNING_MESSAGE);
            }
            else if (ustrand.getSelectedIndex()==0){
            JOptionPane.showMessageDialog(this, "Select your Strand","System",JOptionPane.WARNING_MESSAGE);
            }
            else if (usection.getSelectedIndex()==0){
            JOptionPane.showMessageDialog(this, "Select your Section","System",JOptionPane.WARNING_MESSAGE);
            }
            else if(ustatus.getSelectedIndex()==0)    {
            JOptionPane.showMessageDialog(this, "Select your Status","System",JOptionPane.WARNING_MESSAGE);
            }else{
             int  ok = JOptionPane.showConfirmDialog(rootPane,"Confirm to update", "System",JOptionPane.YES_NO_OPTION);
             if(ok==0){
                 
            JOptionPane.showMessageDialog(this, "Student Info has been changed");        
            pst.executeUpdate();
             database();
            tab.setSelectedIndex(3);
             }}
                            
        } catch (Exception ex) {
             JOptionPane.showMessageDialog(this, ex);
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
       tab.setSelectedIndex(5);
       txtname2.setText("");
       nsection.setSelectedIndex(0);
       nstrand.setSelectedIndex(0);
       nstatus.setSelectedIndex(0);
       cmoa2.setSelected(false);
       cgm2.setSelected(false);
       cf140.setSelected(false);  
       txtid2.setText("0");
       cid2.setSelected(false);
       txtuniform2.setText("0");
       cuniform2.setSelected(false);
       txtgp2.setText("0");
       cgp2.setSelected(false);
       txtcp2.setText("0");
       ccp2.setSelected(false);
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed

         String name=txtname2.getText(); 
         String sec = nsection.getSelectedItem().toString();
         String str = nstrand.getSelectedItem().toString();
         String sta = nstatus.getSelectedItem().toString();
         String moa,gm,f138,id,pid,u,pu,gp,pgp,cp,pcp; 
         
         pu = txtuniform2.getText();
         pgp = txtgp2.getText();
         pcp = txtcp2.getText();
         if(cmoa2.isSelected()){
           moa = "Checked";
         }else{
           moa = "Unchecked";
         }
         if(cgm2.isSelected()){
          gm = "Checked";
         }else{
         gm = "Unchecked";
         }if(cf140.isSelected()){
          f138 = "Checked";
         }else{
         f138 = "Unchecked";
         }if(cid2.isSelected()){
          id = "Checked";
          pid = txtid2.getText();
         }else{
          id = "Unchecked";
          pid = txtid2.getText();
         }if(cuniform2.isSelected()){
          u = "Checked";
         }else{
          u = "Unchecked";
         }if(cgp2.isSelected()){
          gp = "Checked";
         }else{
          gp = "Unchecked";
         }if(ccp2.isSelected()){
          cp = "Checked";
         }else{
          cp = "Unchecked";
         }
        try{

            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("insert into Student_Information (Name,Section,Strand,Status,MOA,"
                    + "Good_Moral,Form_138,ID,ID_Price,Uniform,Uniform_Price,"
                    + "Grad_Picture,Grad_Picture_Price,Class_Picture,Class_Picture_Price) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, name);
            pst.setString(2, sec);
            pst.setString(3, str);
            pst.setString(4, sta);
            pst.setString(5, moa);
            pst.setString(6, gm);
            pst.setString(7, f138);
            pst.setString(8, id);
            pst.setString(9, pid);
            pst.setString(10, u);
            pst.setString(11, pu);
            pst.setString(12, gp);
            pst.setString(13, pgp);
            pst.setString(14, cp);
            pst.setString(15, pcp);  
            if(txtname2.getText().isEmpty()){
            JOptionPane.showMessageDialog(this, "Enter your name","System",JOptionPane.WARNING_MESSAGE);
            }
            else if (nstrand.getSelectedIndex()==0){
            JOptionPane.showMessageDialog(this, "Select your Strand","System",JOptionPane.WARNING_MESSAGE);
            }
            else if (nsection.getSelectedIndex()==0){
            JOptionPane.showMessageDialog(this, "Select your Section","System",JOptionPane.WARNING_MESSAGE);
            }
            else if(nstatus.getSelectedIndex()==0)    {
            JOptionPane.showMessageDialog(this, "Select your Status","System",JOptionPane.WARNING_MESSAGE);
            }else{
            
            int  ok = JOptionPane.showConfirmDialog(rootPane,"Confirm to store", "System",JOptionPane.YES_NO_OPTION);
            if(ok==0){
                JOptionPane.showMessageDialog(rootPane,"New Student has been added", "System",1);
                pst.executeUpdate();
                txtname2.setText("");
                nsection.setSelectedIndex(0);
                nstrand.setSelectedIndex(0);
                nstatus.setSelectedIndex(0);
                cmoa2.setSelected(false);
                cgm2.setSelected(false);
                cf140.setSelected(false);  
                txtid2.setText("0");
                cid2.setSelected(false);
                txtuniform2.setText("0");
                cuniform2.setSelected(false);
                txtgp2.setText("0");
                cgp2.setSelected(false);
                txtcp2.setText("0");
                ccp2.setSelected(false);
                tab.setSelectedIndex(3);
                database();
            }}
        }catch(SQLException ex){
            System.out.println(""+ex);
        }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        tab.setSelectedIndex(3);  
        txtname2.setText("");
        nsection.setSelectedIndex(0);
        nstrand.setSelectedIndex(0);
        nstatus.setSelectedIndex(0);
        cmoa2.setSelected(false);
        cgm2.setSelected(false);
        cf140.setSelected(false);  
        txtid2.setText("0");
        cid2.setSelected(false);
        txtuniform2.setText("0");
        cuniform2.setSelected(false);
        txtgp2.setText("0");
        cgp2.setSelected(false);
        txtcp2.setText("0");
        ccp2.setSelected(false);
        txtcp2.setEnabled(false);
        txtgp2.setEnabled(false);
        txtuniform2.setEnabled(false);
        txtid2.setEnabled(false);
    }//GEN-LAST:event_jButton13ActionPerformed

    private void cid2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cid2ActionPerformed

         try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Price";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){ 
       if(cid2.isSelected()){
        String idp = rs.getString("ID_Price");  
        txtid2.setText(idp);
        
       }else{
        txtid2.setText("0");
       }
    }  
    } 
    catch(Exception ex){
    System.out.println(""+ex);
    }
    }//GEN-LAST:event_cid2ActionPerformed

    private void cuniform2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cuniform2ActionPerformed
     
         try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Price";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){ 
       if(cuniform2.isSelected()){
        String up = rs.getString("Uniform_Price");  
        txtuniform2.setText(up);
        
       }else{
        txtuniform2.setText("0");
       }
    }  
    } 
    catch(Exception ex){
    System.out.println(""+ex);
    }
    }//GEN-LAST:event_cuniform2ActionPerformed

    private void cgp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cgp2ActionPerformed
         
         try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Price";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){ 
       if(cgp2.isSelected()){
        String cp = rs.getString("Graduation_Picture_Price");  
        txtgp2.setText(cp);
        
       }else{
        txtgp2.setText("0");
       }
    }  
    } 
    catch(Exception ex){
    System.out.println(""+ex);
    }
    }//GEN-LAST:event_cgp2ActionPerformed

    private void ccp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ccp2ActionPerformed
             try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Price";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){ 
       if(ccp2.isSelected()){
        String cp = rs.getString("Class_Picture_Price");  
        txtcp2.setText(cp);
        
       }else{
        txtcp2.setText("0");
       }
    }  
    } 
    catch(Exception ex){
    System.out.println(""+ex);
    }
    }//GEN-LAST:event_ccp2ActionPerformed

    private void cid1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cid1ActionPerformed
       try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Price";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){ 
       if(cid1.isSelected()){
        String idp = rs.getString("ID_Price");  
        txtid1.setText(idp);
        
       }else{
        txtid1.setText("0");
       }
    }  
    } 
    catch(Exception ex){
    System.out.println(""+ex);
    }
    }//GEN-LAST:event_cid1ActionPerformed

    private void cuniform1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cuniform1ActionPerformed
       try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Price";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){ 
       if(cuniform1.isSelected()){
        String up = rs.getString("Uniform_Price");  
        txtuniform1.setText(up);
        
       }else{
        txtuniform1.setText("0");
       }
    }  
    } 
    catch(Exception ex){
    System.out.println(""+ex);
    }
    }//GEN-LAST:event_cuniform1ActionPerformed

    private void cgp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cgp1ActionPerformed
         try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Price";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){ 
       if(cgp1.isSelected()){
        String cp = rs.getString("Graduation_Picture_Price");  
        txtgp1.setText(cp);
        
       }else{
        txtgp1.setText("0");
       }
    }  
    } 
    catch(Exception ex){
    System.out.println(""+ex);
    }
    }//GEN-LAST:event_cgp1ActionPerformed

    private void ccpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ccpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ccpActionPerformed

    private void ccp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ccp1ActionPerformed
           try{
    con = PaymentSystem.getConnection();
    String sql= "Select * from Price";
    pst = con.prepareStatement(sql);
    rs=pst.executeQuery();
    while(rs.next()){ 
       if(ccp1.isSelected()){
        String cp = rs.getString("Class_Picture_Price");  
        txtcp1.setText(cp);
        
       }else{
        txtcp1.setText("0");
       }
    }  
    } 
    catch(Exception ex){
    System.out.println(""+ex);
    }
    }//GEN-LAST:event_ccp1ActionPerformed

    private void didActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_didActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_didActionPerformed

    private void duniformActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_duniformActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_duniformActionPerformed

    private void dgpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dgpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dgpActionPerformed

    private void dccpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dccpActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dccpActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
         DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
         int selectedIndex = jTable2.getSelectedRow();
         
        String name = model.getValueAt(selectedIndex, 0).toString();
       
         try{  
           
           con = PaymentSystem.getConnection() ;
           String sql ="select * from Student_Information where Name=?";
            pst = con.prepareStatement(sql);
            pst.setString(1, name); 
            rs = pst.executeQuery();
            while(rs.next()){
           String id,pid,uniform,pu,gp,pgp,cp,pcp;
             id = rs.getString("ID");
             pid = rs.getString("ID_Price");
             uniform = rs.getString("Uniform");
             pu = rs.getString("Uniform_Price");
             gp = rs.getString("Grad_Picture");
             pgp = rs.getString("Grad_Picture_Price");
             cp = rs.getString("Class_Picture");
             pcp = rs.getString("Class_Picture_Price");  

             if(id.equals("Checked")){
             did.setSelected(true);
             txtdid.setText(pid);
             }else{
             did.setSelected(false);
             txtdid.setText(pid);
             }if(uniform.equals("Checked")){
             duniform.setSelected(true);
             txtduniform.setText(pu);
             }else{
             did.setSelected(false);
             txtduniform.setText(pu);
             }if(gp.equals("Checked")){
             dgp.setSelected(true);
             txtdgp.setText(pgp);
             }else{
             dgp.setSelected(false);
             txtdgp.setText(pgp);
             }if(cp.equals("Checked")){
             dccp.setSelected(true);
             txtdcp.setText(pcp);
             }else{
             dccp.setSelected(false);
             txtdcp.setText(pcp);
             }}
         
         
         
         }catch(Exception ex){
          JOptionPane.showMessageDialog(this, ex);
         }
         
    }//GEN-LAST:event_jTable2MouseClicked

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
      
        DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
        int selectedIndex = jTable2.getSelectedRow();
        String name = model.getValueAt(selectedIndex, 0).toString();
        section();
        strand();
        if(jTable2.getSelectedRow() ==-1){
          JOptionPane.showMessageDialog(this, "Select from the tabled");
        }else{
        try{
        con = PaymentSystem.getConnection() ;
        String sql ="select * from Student_Information where Name =?";
        pst = con.prepareStatement(sql);
        pst.setString(1, name);
        rs = pst.executeQuery();
        if(rs.next() == false){
          JOptionPane.showMessageDialog(this, "Student not found");
        
        }else{
             String code,name1,sec,strand,status,moa,gm,form138,id,pid,uniform,pu,gp,pgp,cp,pcp;
             code = rs.getString("Code");
             txtcode1.setText(code);
             name1 = rs.getString("Name");
             sec = rs.getString("Section");
             strand = rs.getString("Strand");
             status = rs.getString("Status");
             moa = rs.getString("MOA");
             gm = rs.getString("Good_Moral");
             form138 = rs.getString("Form_138");
             id = rs.getString("ID");
             pid = rs.getString("ID_Price");
             uniform = rs.getString("Uniform");
             pu = rs.getString("Uniform_Price");
             gp = rs.getString("Grad_Picture");
             pgp = rs.getString("Grad_Picture_Price");
             cp = rs.getString("Class_Picture");
             pcp = rs.getString("Class_Picture_Price");
             txtname1.setText(name1.trim());
             nstrand.setSelectedItem(sec);
             ustrand.setSelectedItem(strand);
             ustatus.setSelectedItem(status.trim());
             if(moa.equals("Checked")){
             cmoa1.setSelected(true);  
             }else{
             cmoa1.setSelected(false);     
             }if(gm.equals("Checked")){
             cgm1.setSelected(true);
             }else{
             cgm1.setSelected(false);
             }if(form138.equals("Checked")){
             cf139.setSelected(true);
             }else{
             cf139.setSelected(false);
             }if(id.equals("Checked")){
             cid1.setSelected(true);
             txtid1.setText(pid);
             }else{
             cid1.setSelected(false);
             txtid1.setText(pid);
             }if(uniform.equals("Checked")){
             cuniform1.setSelected(true);
             txtuniform1.setText(pu);
             }else{
             cid1.setSelected(false);
             txtuniform1.setText(pu);
             }if(gp.equals("Checked")){
             cgp1.setSelected(true);
             txtgp1.setText(pgp);
             }else{
             cid1.setSelected(false);
             txtgp1.setText(pgp);
             }if(cp.equals("Checked")){
             ccp1.setSelected(true);
             txtcp1.setText(pcp);
             }else{
             ccp1.setSelected(false);
             txtcp1.setText(pcp);
             }
             tab.setSelectedIndex(4);
             txtcode.setText("");
             txtname.setText("");
             txtsec.setText("");
             txtstrand.setText("");
             txtstatus.setText("");
             cmoa.setSelected(false);
             cgm.setSelected(false);
             cf138.setSelected(false);  
             txtid.setText("");
             cid.setSelected(false);
             txtuniform.setText("");
             cuniform.setSelected(false);
             txtgp.setText("");
             cgp.setSelected(false);
             txtcp.setText("");
             ccp.setSelected(false);
             txtsearch.setText("");
        }
      
      }catch(Exception ex){
         JOptionPane.showMessageDialog(this, ex);
      } 
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
         DefaultTableModel model = (DefaultTableModel)jTable2.getModel();
         int selectedIndex = jTable2.getSelectedRow();
        String name = model.getValueAt(selectedIndex, 0).toString();
        
        if(jTable2.getSelectedRow() == -1){
          JOptionPane.showMessageDialog(this, "Select from the table");
        }else{
        int dialogresult = JOptionPane.showConfirmDialog(null, "Do you want to delete this record?","System",JOptionPane.YES_NO_OPTION);
        if(dialogresult==JOptionPane.YES_OPTION)
        {
       try {
           
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("delete from Student_Information where Name=?" );  
            pst.setString(1, name);
            pst.executeUpdate();
            database(); 
            txtdid.setText("0");
            did.setSelected(false);
            txtuniform.setText("0");
            duniform.setSelected(false);
            txtdgp.setText("0");
            dgp.setSelected(false);
            txtdcp.setText("0");
            dccp.setSelected(false);   
            JOptionPane.showMessageDialog(this, "Record Deleted");
            }  catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, ex);
            }
            
        
        }}
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
       tab.setSelectedIndex(5);
       txtname2.setText("");
       nsection.setSelectedIndex(0);
       nstrand.setSelectedIndex(0);
       nstatus.setSelectedIndex(0);
       cmoa2.setSelected(false);
       cgm2.setSelected(false);
       cf140.setSelected(false);  
       txtid2.setText("0");
       cid2.setSelected(false);
       txtuniform2.setText("0");
       cuniform2.setSelected(false);
       txtgp2.setText("0");
       cgp2.setSelected(false);
       txtcp2.setText("0");
       ccp2.setSelected(false);
    }//GEN-LAST:event_jButton15ActionPerformed

    private void rSButtonMetro5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro5ActionPerformed
        String section =txtsections.getText();

        try{

            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("insert into Section (Sections) values (?)");

            pst.setString(1,section);
            if(txtsections.getText().isEmpty()){
               JOptionPane.showMessageDialog(this, "Enter your Section","System", JOptionPane.WARNING_MESSAGE);
            }
            else{
                  st = con.createStatement();
                  String sec = "Select * From Section where Sections='"+section+"'";
                 
                  rs = st.executeQuery(sec);
                  if(rs.next()){
                  JOptionPane.showMessageDialog(this, "Section is already Exist","System",JOptionPane.WARNING_MESSAGE);
                  }else{
            
            
            int  ok = JOptionPane.showConfirmDialog(rootPane,"Confirm to store", "System",JOptionPane.YES_NO_OPTION);
            if(ok==0){
                JOptionPane.showMessageDialog(rootPane,"New Section has been saved", "System",1);
                pst.executeUpdate();
                sectiondata();
            }}}
        }catch(SQLException ex){
            System.out.println(""+ex);
        }
    }//GEN-LAST:event_rSButtonMetro5ActionPerformed

    private void rSButtonMetro8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro8ActionPerformed
         DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
         int selectedIndex = jTable3.getSelectedRow();        
         int code = Integer.valueOf(model.getValueAt(selectedIndex, 0).toString());
          
         String section=txtsections.getText();
             
         try {            
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("update Section set Sections=? where code=?");   
            pst.setString(1, section);
            pst.setInt(2, code);
            
            if(txtsections.getText().isEmpty()){
             JOptionPane.showMessageDialog(this, "Enter your section","System",JOptionPane.WARNING_MESSAGE);
            }else{
                  st = con.createStatement();
                  String sec = "Select * From Section where Sections='"+section+"'";
                 
                  rs = st.executeQuery(sec);
                  if(rs.next()){
                  JOptionPane.showMessageDialog(this, "Section is already Exist","System",JOptionPane.WARNING_MESSAGE);
                  }else{
             int  ok = JOptionPane.showConfirmDialog(rootPane,"Confirm to update", "System",JOptionPane.YES_NO_OPTION);
             if(ok==0){
                 
            JOptionPane.showMessageDialog(this, "Section has been changed");
            pst.executeUpdate();
            sectiondata();
             }}}
                            
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, ex);
        }
    }//GEN-LAST:event_rSButtonMetro8ActionPerformed

    private void rSButtonMetro9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro9ActionPerformed
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
        
        
        if(jTable3.getSelectedRow()== -1){
           JOptionPane.showMessageDialog(rootPane, "Select from the table", "System",
                        JOptionPane.OK_OPTION);
        }else{  
        int selectedIndex = jTable3.getSelectedRow();    
        String code = String.valueOf(model.getValueAt(selectedIndex, 0).toString());
       
        int dialogresult = JOptionPane.showConfirmDialog(null, "Do you want to delete this Section?","System",JOptionPane.YES_NO_OPTION);
        if(dialogresult==JOptionPane.YES_OPTION){   
            try {
                con = PaymentSystem.getConnection();
                pst = con.prepareStatement("delete from Section where code=?" );
                pst.setString(1, code);
                pst.executeUpdate();
                txtcodes.setText("");
                txtsections.setText("");
                sectiondata();
                JOptionPane.showMessageDialog(this, "Section Deleted");
            } catch (SQLException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);}
            }}
    }//GEN-LAST:event_rSButtonMetro9ActionPerformed

    private void rSButtonMetro10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro10ActionPerformed
       String strand =txtstrandd.getText();

        try{

            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("insert into Strand (Strand) values (?)");

            pst.setString(1,strand);
            if(txtstrandd.getText().isEmpty()){
             JOptionPane.showMessageDialog(this, "Enter your Strand","System",JOptionPane.WARNING_MESSAGE);
            }else{
                  st = con.createStatement();
                  String str = "Select * From Strand where Strand='"+strand+"'";  
                  rs = st.executeQuery(str);
                  if(rs.next()){
                  JOptionPane.showMessageDialog(this, "Strand is already Exist","System",JOptionPane.WARNING_MESSAGE);
                  }else{
            int  ok = JOptionPane.showConfirmDialog(rootPane,"Confirm to store", "System",JOptionPane.YES_NO_OPTION);
            if(ok==0){
                JOptionPane.showMessageDialog(rootPane,"New Strand has been saved", "System",1);
                pst.executeUpdate();
                Stranddata();
            }}}
        }catch(SQLException ex){
            System.out.println(""+ex);
        }
    }//GEN-LAST:event_rSButtonMetro10ActionPerformed

    private void rSButtonMetro11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro11ActionPerformed
         DefaultTableModel model = (DefaultTableModel)jTable4.getModel();
         int selectedIndex = jTable4.getSelectedRow();        
         int code = Integer.valueOf(model.getValueAt(selectedIndex, 0).toString());
          
         String Strand=txtstrandd.getText();
             
         try {            
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("update Strand set Strand=? where Code=?");   
            pst.setString(1, Strand);
            pst.setInt(2, code);
            if(txtstrandd.getText().isEmpty()){
             JOptionPane.showMessageDialog(this, "Enter your Strand","System",JOptionPane.WARNING_MESSAGE);
            }else{
                  st = con.createStatement();
                  String str = "Select * From Strand where Strand='"+Strand+"'";  
                  rs = st.executeQuery(str);
                  if(rs.next()){
                  JOptionPane.showMessageDialog(this, "Strand is already Exist","System",JOptionPane.WARNING_MESSAGE);
                  }else{
             int  ok = JOptionPane.showConfirmDialog(rootPane,"Confirm to update", "System",JOptionPane.YES_NO_OPTION);
             if(ok==0){
                 
            JOptionPane.showMessageDialog(this, "Strand has been changed");
            pst.executeUpdate();
            Stranddata();
             }}}
                            
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, ex);
        }
    }//GEN-LAST:event_rSButtonMetro11ActionPerformed

    private void rSButtonMetro12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro12ActionPerformed
        DefaultTableModel model = (DefaultTableModel)jTable4.getModel();
        
        
        if(jTable4.getSelectedRow()== -1){
           JOptionPane.showMessageDialog(rootPane, "Select from the table", "System",
                        JOptionPane.OK_OPTION);
        }else{  
        int selectedIndex = jTable4.getSelectedRow();    
        String code = String.valueOf(model.getValueAt(selectedIndex, 0).toString());
       
        int dialogresult = JOptionPane.showConfirmDialog(null, "Do you want to delete this Strand?","System",JOptionPane.YES_NO_OPTION);
        if(dialogresult==JOptionPane.YES_OPTION){   
            try {
                con = PaymentSystem.getConnection();
                pst = con.prepareStatement("delete from Strand where code=?" );
                pst.setString(1, code);
                pst.executeUpdate();
                txtcodestrand.setText("");
                txtstrandd.setText("");
                Stranddata();
                JOptionPane.showMessageDialog(this, "Strand Deleted");
            } catch (SQLException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);}
            }}
    }//GEN-LAST:event_rSButtonMetro12ActionPerformed

    private void rSButtonMetro14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rSButtonMetro14ActionPerformed
         DefaultTableModel model = (DefaultTableModel)jTable5.getModel();
         int selectedIndex = jTable5.getSelectedRow();        
         int code = Integer.valueOf(model.getValueAt(selectedIndex, 0).toString());
         String idprice,uprice,classprice,gradprice;
         idprice=txtidprice.getText();
         uprice = txtuprice.getText();
         classprice = txtclassprice.getText();
         gradprice = txtgradprice.getText();
             
         try {            
            con = PaymentSystem.getConnection();
            pst = con.prepareStatement("update Price set ID_Price=?,Uniform_Price=?,Class_Picture_Price=?,"
                    + "Graduation_Picture_Price=? where Price_Code=?");   
            pst.setString(1, idprice);
            pst.setString(2, uprice);
            pst.setString(3, classprice);
            pst.setString(4, gradprice);
            pst.setInt(5, code);
            if(jTable5.getSelectedRow() == -1 ){
                   JOptionPane.showMessageDialog(this, "Select from the table","System", JOptionPane.WARNING_MESSAGE);
            }else if(txtidprice.getText().isEmpty()){
                  JOptionPane.showMessageDialog(this, "Enter ID price","System", JOptionPane.WARNING_MESSAGE);
            }else if(txtuprice.getText().isEmpty()){
                  JOptionPane.showMessageDialog(this, "Enter Uniform price","System", JOptionPane.WARNING_MESSAGE);
            }else if(txtclassprice.getText().isEmpty()){
                  JOptionPane.showMessageDialog(this, "Enter Class Picture price","System", JOptionPane.WARNING_MESSAGE);
            }else if(txtgradprice.getText().isEmpty()){
                  JOptionPane.showMessageDialog(this, "Enter Graduation Picture price","System", JOptionPane.WARNING_MESSAGE);
            }  
            else{
             int  ok = JOptionPane.showConfirmDialog(rootPane,"Confirm to update", "System",JOptionPane.YES_NO_OPTION);
             if(ok==0){
                 
            JOptionPane.showMessageDialog(this, "New Price has been changed");
            pst.executeUpdate();
            PriceItem();
            txtidprice.setText("");
            txtuprice.setText("");
            txtclassprice.setText("");
            txtgradprice.setText("");
             }}
                            
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex);
        }
    }//GEN-LAST:event_rSButtonMetro14ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        tab.setSelectedIndex(9);
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        tab.setSelectedIndex(6);
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        tab.setSelectedIndex(7);
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        tab.setSelectedIndex(8);
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jTable3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable3MouseClicked
        DefaultTableModel model = (DefaultTableModel)jTable3.getModel();
         int selectedIndex = jTable3.getSelectedRow();
        txtcodes.setText(model.getValueAt(selectedIndex, 0).toString());
        txtsections.setText(model.getValueAt(selectedIndex, 1).toString());  
    }//GEN-LAST:event_jTable3MouseClicked

    private void jTable4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable4MouseClicked
        DefaultTableModel model = (DefaultTableModel)jTable4.getModel();
        int selectedIndex = jTable4.getSelectedRow();
        txtcodestrand.setText(model.getValueAt(selectedIndex, 0).toString());
        txtstrandd.setText(model.getValueAt(selectedIndex, 1).toString()); 
    }//GEN-LAST:event_jTable4MouseClicked

    private void jTable5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable5MouseClicked
        DefaultTableModel model = (DefaultTableModel)jTable5.getModel();
        int selectedIndex = jTable5.getSelectedRow();
        txtcodeprice.setText(model.getValueAt(selectedIndex, 0).toString());
        txtidprice.setText(model.getValueAt(selectedIndex, 1).toString()); 
        txtuprice.setText(model.getValueAt(selectedIndex, 2).toString());
        txtclassprice.setText(model.getValueAt(selectedIndex, 3).toString());
        txtgradprice.setText(model.getValueAt(selectedIndex, 4).toString());
    }//GEN-LAST:event_jTable5MouseClicked

    private void nstrandActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nstrandActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nstrandActionPerformed

    private void btnminimizeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnminimizeActionPerformed
        this.setState(ICONIFIED);
    }//GEN-LAST:event_btnminimizeActionPerformed

    private void btnexitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnexitActionPerformed
        int x = JOptionPane.showConfirmDialog(rootPane, "Do you want to Exit?", "Accounts and Payments System", JOptionPane.YES_NO_OPTION);
        if (x == 0) {
            System.exit(0);
        }
    }//GEN-LAST:event_btnexitActionPerformed
    private int xMouse,yMouse;
    private void jPanel3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel3MousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_jPanel3MousePressed

    private void jPanel3MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel3MouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_jPanel3MouseDragged

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnexit;
    private javax.swing.JButton btnminimize;
    private javax.swing.JCheckBox ccp;
    private javax.swing.JCheckBox ccp1;
    private javax.swing.JCheckBox ccp2;
    private javax.swing.JCheckBox cf138;
    private javax.swing.JCheckBox cf139;
    private javax.swing.JCheckBox cf140;
    private javax.swing.JCheckBox cgm;
    private javax.swing.JCheckBox cgm1;
    private javax.swing.JCheckBox cgm2;
    private javax.swing.JCheckBox cgp;
    private javax.swing.JCheckBox cgp1;
    private javax.swing.JCheckBox cgp2;
    private javax.swing.JCheckBox cid;
    private javax.swing.JCheckBox cid1;
    private javax.swing.JCheckBox cid2;
    private javax.swing.JCheckBox cmoa;
    private javax.swing.JCheckBox cmoa1;
    private javax.swing.JCheckBox cmoa2;
    private javax.swing.JCheckBox cuniform;
    private javax.swing.JCheckBox cuniform1;
    private javax.swing.JCheckBox cuniform2;
    private javax.swing.JCheckBox dccp;
    private javax.swing.JCheckBox dgp;
    private javax.swing.JCheckBox did;
    private javax.swing.JCheckBox duniform;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel26;
    private javax.swing.JPanel jPanel27;
    private javax.swing.JPanel jPanel28;
    private javax.swing.JPanel jPanel29;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel30;
    private javax.swing.JPanel jPanel31;
    private javax.swing.JPanel jPanel32;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTable jTable5;
    private javax.swing.JLabel lbldate;
    private javax.swing.JLabel lbltime;
    private javax.swing.JComboBox<String> nsection;
    private javax.swing.JComboBox<String> nstatus;
    private javax.swing.JComboBox<String> nstrand;
    private rsbuttom.RSButtonMetro rSButtonMetro10;
    private rsbuttom.RSButtonMetro rSButtonMetro11;
    private rsbuttom.RSButtonMetro rSButtonMetro12;
    private rsbuttom.RSButtonMetro rSButtonMetro14;
    private rsbuttom.RSButtonMetro rSButtonMetro2;
    private rsbuttom.RSButtonMetro rSButtonMetro3;
    private rsbuttom.RSButtonMetro rSButtonMetro4;
    private rsbuttom.RSButtonMetro rSButtonMetro5;
    private rsbuttom.RSButtonMetro rSButtonMetro7;
    private rsbuttom.RSButtonMetro rSButtonMetro8;
    private rsbuttom.RSButtonMetro rSButtonMetro9;
    private javax.swing.JTabbedPane tab;
    private javax.swing.JTextField txtclassprice;
    private javax.swing.JTextField txtcode;
    private javax.swing.JTextField txtcode1;
    private javax.swing.JTextField txtcodeprice;
    private javax.swing.JTextField txtcodes;
    private javax.swing.JTextField txtcodestrand;
    private javax.swing.JTextField txtcp;
    private javax.swing.JTextField txtcp1;
    private javax.swing.JTextField txtcp2;
    private javax.swing.JTextField txtdcp;
    private javax.swing.JTextField txtdgp;
    private javax.swing.JTextField txtdid;
    private javax.swing.JTextField txtduniform;
    private javax.swing.JTextField txtgp;
    private javax.swing.JTextField txtgp1;
    private javax.swing.JTextField txtgp2;
    private javax.swing.JTextField txtgradprice;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtid1;
    private javax.swing.JTextField txtid2;
    private javax.swing.JTextField txtidprice;
    private javax.swing.JTextField txtname;
    private javax.swing.JTextField txtname1;
    private javax.swing.JTextField txtname2;
    private javax.swing.JTextField txtpass;
    private javax.swing.JPasswordField txtpassc;
    private javax.swing.JPasswordField txtpasscp;
    private javax.swing.JTextField txtsearch;
    private javax.swing.JTextField txtsec;
    private javax.swing.JTextField txtsections;
    private javax.swing.JTextField txtstatus;
    private javax.swing.JTextField txtstrand;
    private javax.swing.JTextField txtstrandd;
    private javax.swing.JTextField txtuniform;
    private javax.swing.JTextField txtuniform1;
    private javax.swing.JTextField txtuniform2;
    private javax.swing.JTextField txtuprice;
    private javax.swing.JTextField txtuser;
    private javax.swing.JTextField txtuserc;
    private javax.swing.JTextField txtusercp;
    private javax.swing.JButton ubtncancel;
    private javax.swing.JComboBox<String> usection;
    private javax.swing.JComboBox<String> ustatus;
    private javax.swing.JComboBox<String> ustrand;
    // End of variables declaration//GEN-END:variables
}
